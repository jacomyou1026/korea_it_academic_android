package com.lhe.covid19;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.GridView;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    Date currentTime = Calendar.getInstance().getTime();

    TextView txt_date, regionName, reg_defCnt, reg_incDec, reg_death;

    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
    String current = sdf.format(currentTime);


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        GridView gridView_region = findViewById(R.id.gridView_region);
        GridListAdapter adapter = new GridListAdapter();

        txt_date = findViewById(R.id.txt_date);
        regionName = findViewById(R.id.regionName);
        reg_defCnt = findViewById(R.id.reg_defCnt);
        reg_incDec = findViewById(R.id.reg_incDec);
        reg_death = findViewById(R.id.reg_death);
        txt_date.setText(current+" 기준");

        /*adapter.addItem(new RegionConfirmedList());*/

    }

}