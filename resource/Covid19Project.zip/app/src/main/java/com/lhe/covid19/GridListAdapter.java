package com.lhe.covid19;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class GridListAdapter extends BaseAdapter {

    ArrayList<RegionConfirmedList> items = new ArrayList<RegionConfirmedList>();
    Context context;

    public void addItem(RegionConfirmedList rcList) {
        items.add(rcList);
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View gridView, ViewGroup parent) {
        context = parent.getContext();
        RegionConfirmedList rcList = items.get(position);

        if(gridView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            gridView = inflater.inflate(R.layout.list_item, parent, false);
        }

        // xml에 TextView를 참조
        TextView regionName = gridView.findViewById(R.id.regionName);
        TextView reg_defCnt = gridView.findViewById(R.id.reg_defCnt);
        TextView reg_incDec = gridView.findViewById(R.id.reg_incDec);
        TextView reg_death = gridView.findViewById(R.id.reg_death);

        return gridView;
    }

}
